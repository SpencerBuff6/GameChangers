
<br/>
<hr/>
</body>
<footer>
    Game Changers - <?php echo $pageName ?> - Copyright 2022
</footer>

</html>
